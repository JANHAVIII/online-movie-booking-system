package com.cg.mts.exception;

import java.util.Date;

public class ErrorMapper {

	public ErrorMapper(String uri, String msg, Date date) {
		// TODO Auto-generated constructor stub
	}

}
